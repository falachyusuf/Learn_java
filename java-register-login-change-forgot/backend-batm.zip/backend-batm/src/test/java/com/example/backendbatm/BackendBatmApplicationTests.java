package com.example.backendbatm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendBatmApplicationTests {

	@Test
	void contextLoads() {
	}

}
