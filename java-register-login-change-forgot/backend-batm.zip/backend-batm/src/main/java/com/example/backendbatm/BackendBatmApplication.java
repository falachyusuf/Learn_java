package com.example.backendbatm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendBatmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendBatmApplication.class, args);
	}

}
