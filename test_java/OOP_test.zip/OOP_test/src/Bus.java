public class Bus extends Roda4 {

    public Bus () {

    }

    public void Maju(){
        System.out.println("Kendaraan ini memiliki banyak pintu" + getBanyak_pintu() + "dan berwarna "  + getWarna());
        System.out.println("Kendaraan ini sedang berjalan maju dengan  " + getKecepatan() + " km/jam");
    }

}
