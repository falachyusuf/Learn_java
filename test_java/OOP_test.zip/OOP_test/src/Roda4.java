public abstract class Roda4 {
    private String warna;
    private int banyak_pintu;
    private int kecepatan;

    public Roda4(){
    }

    abstract void Maju();

    public String getWarna() {
        return warna;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public int getBanyak_pintu() {
        return banyak_pintu;
    }

    public void setBanyak_pintu(int banyak_pintu) {
        this.banyak_pintu = banyak_pintu;
    }

    public int getKecepatan() {
        return kecepatan;
    }

    public void setKecepatan(int kecepatan) {
        this.kecepatan = kecepatan;
    }


}
