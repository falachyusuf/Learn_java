public class Mobil extends Roda4 {

    public Mobil () {

    }
    public void Maju(){
        System.out.println("Kendaraan ini memiliki banyak pintu" + getBanyak_pintu() + "dan berwarna "  + getWarna());
        System.out.println("Kendaraan ini sedang berjalan maju dengan kecepatan " + getKecepatan() + " km/jam");
    }
}
